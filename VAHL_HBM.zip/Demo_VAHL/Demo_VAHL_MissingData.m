
%% This is a demo for View-Aligned Hypergraph Learning(VAHL) with multi-modality missing data
% We construct a hypergraph in each modality, and learn the weight for modalities;
% We learn weights for hyperedges in each hypergraph;
% We also predict scores for the samples;
% That is, we learn the predicited label, weights for hyperedges, and weights for different hypergraphs simultaneously.

%% Objective function: 
% min_{F,Alpha,W_1,W_2,...,W_M}  (norm(F-Y))^2 + Simgma_{m=1,2,...,M}( Alpha(m) * F' * Delta_m * F ) +...
%                                + mu * Sigma_{i=1,2,...,M}(norm(W_m))^2 + lambda * (norm(Alpha))^2
% M is the modality number
% Alpha is a M-dimensional vector with each element denotes the weight for each modality
% W_m is the diagonal matrix, with diagonal element denoting the weight for each hyperedge in the m-th modality
% Y is the label vector for the training and the test data, where +1 for positive, -1 for negative, and 0 for unknown class. 
% Note that the class labels for the test data in the initial Y is 0;
% F is the predicted scores.
% By Mingxia Liu in UNC at Chapel Hill, 01/18/2016.

%%
clear all;
clc;

%% Simulation distance matrices
Data = [];
Data(:, 1:93) = rand(100,93);
Data(:, 94:186) = rand(100,93);
Data(:, 187:191) = rand(100,5);
Data(1:20,94:186) = nan;
Data(21:50,187:end) = nan;

index = [];
index = ones(size(Data,1),3);
index(1:20,2) = 0;
index(21:50,3) = 0;
Omega = [];
Omega{1} = diag(index(:,1));
Omega{2} = diag(index(:,2));
Omega{3} = diag(index(:,3));
aa=1;

%% Parameter settings
% mPara.mDist = mDist;
% n*1 cell, the distance matrix for all samples

mPara.IS_ProH = 0;
% IS_ProH is to determine whether the hypergraph incidence matrix is constructed probabilistically
% 1: the entry of H is a probability,    0: the entry of H is 1 or 0.
% Generally, IS_ProH = 1 works better.

mPara.mProb = 0.05;
% The parameter for probabilistic incidence matrix (exp(-d^2/sigma^2), sigma = mPro.aveDist)
% It is usually set as 0.05 or 0.1

mPara.GraphType = 1;
% The neighbor selection method
% 1: star expansion using mStarExp   2: distance-based using mRatio

mPara.mStarExp = 10; 
% The number of star expansion
% It can be set as 5, 10, 20, or other numbers

mPara.mRatio = 0.1;
% The ratio of average distance to select neighbor
% It is set as 0.1 or 1. We need to check the incidence matrix H to determine it

mPara.IsWeight = 1;
% Whether learn the hypergraph weight during learning process
% 1: learn  0:no-learn

mPara.lambda = 10;%1000;
% The parameter on empirical loss in hypergraph learning
% lambda may range from 10e-2 to 10e4

mPara.mu = 10%10;
% The parameter on the hyperedge weight in hypergraph learning
% mu may range from 10e-2 to 10e4

mPara.nIter = 30;
% The maximal iteration times for learning
% The iteration may stop in no more than 20 rounds.

mPara.IsAlpha = 1;
%mPara. IsAlpha=0;
% Whether learn the weight for differnt modality (hypergraph) during learning process
% 1: learn  0:no-learn

%% Initialize Y
nObject = size(Data,1); % number of objects in the learning process
Y = -1 * ones(nObject,1);
Y(1:60,1) = 1;% the query is set as 1
%%%%%%%%%%%%%%%%%
  
%% The main procedures
numModal = 3; % MRI, PET, and CSF
fusion = 1;

%% Data grouping and hypergraph construction
[H, W ] = DataGrouping( Data, mPara, fusion );

[F newW Alpha costValue] = VAHL_Lambda_new(H,W,Y,mPara,Omega); % Joint Learning Process

figure;
plot([costValue(:,1)])

aa=1;

