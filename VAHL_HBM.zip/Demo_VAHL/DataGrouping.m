function [ H, W ] = DataGrouping( Data, mPara, fusion )

% Find MRI 
iMRI = Data(:,1:93);
mPara.mDist{1,1} = dist(iMRI');
initialW = [];
[mriH initialW] = HGConstruction(mPara);
W{1} = initialW{1,1};
H1 = mriH{1,1};
aa=1;

% Find PET 
iPET = Data(:,94:186);
index = find(~isnan(iPET(:,1)));
petData = iPET( index , : );
mPara.mDist{1,1} = dist(petData');
[petH initialW] = HGConstruction(mPara);
W{2} = initialW{1,1};
H2 = petH{1,1};

% Find CSF 
iCSF = Data(:,187:end);
index = find(~isnan(iCSF(:,1)));
csfData = iCSF( index , : );
mPara.mDist{1,1} = dist(csfData');
initialW=[];
[csfH initialW] = HGConstruction(mPara);
W{3} = initialW{1,1};
H3 = csfH{1,1};


if fusion==1 % use 3 combination way, MRI, PET, CSF
    H{1} = H1;
    H{2} = H2;
    H{3} = H3; %[H1 H2 H3];
end
if fusion==2  % use 6 combination way, MRI, PET, CSF, MRI+PET, MRI+CSF, MRI+PET+CSF
    H=[H4 H5 H6];
end
if fusion==3  % use 6 combination way, MRI, PET, CSF, MRI+PET, MRI+CSF, MRI+PET+CSF
    H=[H1 H2 H3 H4 H5 H6];
end


end

