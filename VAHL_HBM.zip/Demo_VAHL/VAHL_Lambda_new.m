function [F W Alpha costValue ] = VAHL_Lambda_new(H,W,Y,mPara,Omega,err)
%% View-Alinged Hypergraph learning with hyperedge weight learning, and modality weigh learning 
% Each hypergraph is corresponding to a modality;
% To jointly learn the weight for each modality Alpha(m,1),  
%     , the weight for each hyperedge in each modality W^m;
%     , and the predicted score F for nObject samples;

% Objective function:
% min _ {F,newW, Alpha}  1/N * Sigma_{m=1,..M}|| Omega{m}*(F^m-Y)||^2 + Sigma_{m=1,..M} (Alpha(m,1)^2 * F^m' * Delta^m * F^m)
%                        + mu * Sigma_{n=1,..,N} Sigma_{m=1,..,M}Sigma_{p=1,..M} ( Omega^m(n,n) * Omega^p(n,n) * ||f_n^m-f_n^p||^2 ) 
%                        + 1/N * lambda * Sigma_{m=1,..M}||W^m||^2                         
% s.t.   Alpha' *1 = 1, 0=< Alpha <=1;
%        diag(W^m)' * 1 = 1, W^m>0, for any m=1,...,M;

% F_m and Y are nObject*1 vectors;
% W^m is a diagonal matrix, with diagonal element denoting weight for hyperedge in the m-th modality
%     , while diag(W^m) is a vector Em*1 dimension, Em is the hyperedge number in m-th modality; ;
% Alpha is a M*1 vector, with each element denoting weight for each modality
% H and W is a cell of M modalities, H{m}
% Omega{m} is a nObject*nObject diagonal matrix, with diagonal element Omega_nn=1 if the
%          n-th subject has the m-th modlity, otherwise 0.


%% parameter setting
nMod = size( H,2); % number of modalities or distance matrices
nObject = size(H{1},1); % number of objects in the learning process
for iM=1:nMod
    nEdge(iM,1) = size(H{iM},2); % number of hyperedges
end
IsWeight = mPara.IsWeight;% whether learn hyperedge weight
nIter = mPara.nIter;
lambda = mPara.lambda;
mu = mPara.mu;
% newW=[]; % Learned weights for hypergedges
IsAlpha = mPara. IsAlpha; % whether learn the weight for different modalities

%%%%%%%%%%%%%%%%%%
gap = 10;
iIter = 1;
if ~exist('err', 'var')
    err = 1.0e-3;
end


%% Initialization
F = zeros(nObject,nMod);
Alpha=zeros(nMod,1)+1/nMod; % Default weight for differnt hypergraphs

%% Compute the initial function cost value
sumW=0;viewAlign=0;sumTheta=0; loss=0;
for iM=1:nMod  % nMod modalities 
    nObject_mod = size(H{iM},1);
    DV{iM} = eye(nObject_mod);
    for iObject = 1:nObject_mod
        DV{iM}(nObject_mod,nObject_mod) = sum(H{iM}(nObject_mod,:).*W{iM}'); 
        if (DV{iM}(nObject_mod,nObject_mod))==0  % To avoid NaN
            DV{iM}(nObject_mod,nObject_mod)=1;
        end
    end
    DE{iM} = eye(nEdge(iM,1));
    for iEdge = 1:nEdge(iM,1)
        DE{iM}(iEdge,iEdge)=sum(H{iM}(:,iEdge));
    end
    DV2{iM} = DV{iM}^(-0.5);
    INVDE{iM} = DE{iM}^(-1); % inv(DE{iM});
    Theta{iM} = Alpha(iM,1)^2 * (eye(nObject_mod)- DV2{iM}*H{iM}*diag(W{iM})*INVDE{iM}*H{iM}'*DV2{iM} );
    sumW = sumW + norm(W{iM})^2 / iEdge;
    iIndex = find (diag(Omega{iM})==1); 
    for pp = 1:nMod
        viewAlign = viewAlign + norm(Omega{iM} * Omega{pp} * (F(:,iM)-Y), 2)^2/ length(iIndex);
    end
    iIndex = find (diag(Omega{iM})==1); 
    sumTheta = sumTheta+ F(iIndex,iM)'*Theta{iM}*F(iIndex,iM);
    loss = loss + norm(Omega{iM}*(F(:,iM)-Y))^2 / length(iIndex);
end

costValue_old = loss + sumTheta + mu*viewAlign+ lambda*sumW;


%%%%%%%%%%%%%%%%%%
  
if IsWeight == 1% if weight learning is required
    flag = 1;
   
%   while gap > err && iIter < 101
%       gap
    for iIter = 1:nIter
        if flag == 1          
          %% Given fixed W and Alpha, update F 
           allOmega = zeros(nObject,nObject);
           allOmegaF = zeros (nObject,1);           
           for iM=1:nMod  % nMod modalities  
               nObject_mod = size(H{iM},1);
               DV{iM} = eye(nObject_mod);

               for iObject = 1:nObject_mod
                  DV{iM}(nObject_mod,nObject_mod) = sum(H{iM}(nObject_mod,:).*W{iM}');
                  if (DV{iM}(nObject_mod,nObject_mod)==0)
                      DV{iM}(nObject_mod,nObject_mod)=1;
                  end
               end
               DE{iM} = eye(nEdge(iM,1));
               for iEdge = 1:nEdge(iM,1)
                   DE{iM}(iEdge,iEdge)=sum(H{iM}(:,iEdge));
               end
               DV2{iM} = DV{iM}^(-0.5);
               INVDE{iM} = DE{iM}^(-1); % inv(DE{iM});
               Theta{iM} = Alpha(iM,1)^2* (eye(nObject_mod)- DV2{iM}*H{iM}*diag(W{iM})*INVDE{iM}*H{iM}'*DV2{iM} );
               allOmega = allOmega + Omega{iM};
               allOmegaF = allOmegaF +  Omega{iM}*F(:,iM);
           end
          
           for iM=1:nMod
               nObject_mod = size(H{iM},1);
               iIndex = find (diag(Omega{iM})==1); 
               myI = diag( ones(length(iIndex),1) );
               iA = diag(allOmega);
               newAllOmega = diag( iA(iIndex,1) );
               newAllOmegaF = allOmegaF(iIndex,1);
               F(iIndex,iM) = ( myI * (1/nObject_mod) + Theta{iM} + 2*mu*myI*newAllOmega/ length(iIndex) ) \ ( myI*Y(iIndex,1)* (1/nObject_mod) + mu/ length(iIndex) * myI*newAllOmegaF);
%                F(:,iM) = ( Omega{iM} + Theta{iM} + 2*mu*Omega{iM}*allOmega ) \ ( Omega{iM}*Y + mu * Omega{iM}*allOmegaF);
           end           


               %% save current F and the previous F
                if iIter > 1
                    mF{1,1} = mF{2,1};
                    mF{2,1} = F;
                else
                    mF{2,1} = F;
                end
                
             %% Given fixed F and Alpha, update hyperedge weight W
             % Here we use quadratic programming to optimize each Wm separately
             for iM=1:nMod 
                 iIndex = find (diag(Omega{iM})==1);
                 nObject_mod = size(H{iM},1);
                 Gamma = F(iIndex,iM)' * DV2{iM} * H{iM};
                 iEta = ( Alpha(iM,1)^2 * Gamma * INVDE{iM} * Gamma' - 2*lambda/nObject_mod ) / size(W{iM},1);
%                  aa=  Alpha(iM,1)^2 * Gamma'* Gamma * INVDE{iM};
%                  bb= iEta * eye(size(W{iM},1));
                 newW{iM} = ( Alpha(iM,1)^2 * Gamma'* Gamma * INVDE{iM} - iEta * eye(size(W{iM},1)) ) * nObject_mod / (2*lambda);
                 W{iM} = zeros ( size(newW{iM},1), 1);
                 for a_i=1:size(newW{iM},1)
                     W{iM}(a_i,1) = newW{iM}(a_i,a_i);
                 end
                 aa=1;
%                      % term3 is different size with term1 and term2
%                  term1 = 1/nEdge(iM,1);
%                  term2 = -(F(iIndex,iM)'*Gamma*INVDE{iM}*Gamma'*F(iIndex,iM))/(2*nEdge(iM,1)*mu);
%                  term3 = diag(((F(iIndex,iM)'*Gamma).^2 * INVDE{iM}))/(2*mu);
%                  %     W = (term1+term2)*eye(n_e)+term3;
%                  newW{iM} = (term1+term2)*diag((ones(nEdge(iM,1),1))) + term3;                 
%                  
%                  W{iM} = diag(newW{iM});
%                  W{iM} = jb_scaling(W{iM},0,1);                
             end
             
             %% Given fixed F and W, update hyperedge weight Alpha
                if IsAlpha==1
                  % cvx specification
                  iG=zeros(nMod,1);

                  for iM=1:nMod
                      iIndex = find (diag(Omega{iM})==1);
                      nObject_mod = size(H{iM},1);
                      iG(iM,1)=F(iIndex,iM)'*( eye(nObject_mod)- DV2{iM}*H{iM}*diag(W{iM})*INVDE{iM}*H{iM}'*DV2{iM} )*F(iIndex,iM);
                  end
                  multiplyG=ones(nMod,1);
                  mulG=1;
                  for iM=1:nMod
                      for jM=1:nMod
                          if jM~=iM
                              multiplyG(iM,1) = multiplyG(iM,1) * iG(jM,1);
                          end
                      end
                      mulG = mulG * iG(iM,1);
                  end
                  tau = - mulG / ( multiplyG'*ones(nMod,1) );
                  for iM=1:nMod
                      Alpha(iM,1) = - tau / iG(iM,1);
%                       if Alpha(iM,1)<0
%                           Alpha(iM,1)=0;
%                       end
                  end
aa=1;

                end

                
              %% Calculate the cost function
              sumW=0;viewAlign=0;sumTheta=0; loss=0;
              for iM=1:nMod
                  iIndex = find (diag(Omega{iM})==1);
                  nObject_mod = size(H{iM},1);
                  sumW = sumW + norm(W{iM})^2 / iEdge;
                  for pp = 1:nMod
                      viewAlign = viewAlign + norm(Omega{iM} * Omega{pp} * (F(:,iM)-Y), 2)^2 / length(iIndex);
                  end
                  sumTheta = sumTheta+ F(iIndex,iM)'*Theta{iM}*F(iIndex,iM);
                  loss = loss + norm(Omega{iM}*(F(:,iM)-Y))^2 / length(iIndex);
              end
%               viewAlign = viewAlign/(nMod*nMod);
              costValue(iIter,1) = loss + sumTheta + mu*viewAlign + lambda*sumW;
              costValue(iIter,2) = loss;
              costValue(iIter,3) = sumTheta;
              costValue(iIter,4) = mu*viewAlign;
              costValue(iIter,5) = lambda*sumW;
%   end  % gap and iteration
     aa=1;           
                if iIter > 1
                    disp(['Iteration = ' num2str(iIter) ' The cost value is ' num2str(costValue(iIter,1)) ' The cost value is reduced by ' num2str(costValue(iIter) - costValue(iIter-1))]);
                     if  ( costValue(iIter) - costValue(iIter-1)) > -0.00001 % if the cost value does not decrease again, stop the iteration
%                      if  abs( costValue(iIter,1) - costValue(iIter-1,1)) < 0.00001 % if the cost value does not decrease again, stop the iteration

                         flag = 0;
                         disp(['Iteration stops after ' num2str(iIter-1) ' round.']);
                         F = mF{1,1};
%                          bar(W);
%                          newW=W;
                     end
                 else                     
                     disp(['Iteration = ' num2str(iIter) ' The cost value is ' num2str(costValue(iIter,1))]);
                 end
        end       
    end
end
aa=1;

end